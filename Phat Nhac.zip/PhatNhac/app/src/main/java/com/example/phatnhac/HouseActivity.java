package com.example.phatnhac;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;

public class HouseActivity extends AppCompatActivity {

    private RecyclerView recyclerViewDanhSachNhac;
    private EditText searchName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house);
        initview();
    }

    private void initview() {

        recyclerViewDanhSachNhac = findViewById(R.id.recyclerViewDanhSachNhac);
        searchName               = findViewById(R.id.searchName);
    }
}
